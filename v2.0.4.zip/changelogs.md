# CHANGELOGS

# 2.0.3
> fixed big screen now it's functional 
> additionally ready to add some new features
# 2.0.3
> used plugin icon as tab icon

# V 2.0.2
> fixed server offline error 

# V 2.0.0

### INTRODUCING `LIVE SERVER 2.0`

**`what's new ?`**

> now live server is avilable on seprate tab so that user will be able to preview `WEB PAGE` work on a seprate tab which provides better view and controls

# V 1.1.3
> Added "repository" link, its an free plugin 

# V 1.1.2
> fixed the live button bug
> improved overall code readability
> Made Ready to recive another upcomming big update

# V 1.1.1
> fixed the `unable to install` error

